package InterfaceCocept14;

public interface USBank {
int min_bal = 100;
//int min_bal = 200;-- variable value will not change not allow error will come, sataic in nature
public void credit();
public void debit();
public void transferMoney();

//only method declaration
//no method body - only method prototype
//In interface - we can declare the variable, vars are by default static in nature, its final in nature
//no static method in interface
//no main method
// we can not create the object of interface
// interface is abstract in nature- we can not instasiate in object


}
