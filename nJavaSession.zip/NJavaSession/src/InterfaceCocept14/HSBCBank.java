package InterfaceCocept14;

public class HSBCBank implements USBank,BrazilBank { // we are achiving multiple inheritanve
	// is - a -->>relation ship-- inter face relation ship  with class  impliment key word
	//has - a --> relation ship is  class to class  extend keywords
	//if a class is implimenting any interface, then it mandatory to define/override all the metod interface.
	
	//below method  overriding from usbank
	public void credit()
	{
		System.out.println("hsbc---credit");
	}
	public void debit()
	{
		System.out.println("hsbc---debit");
	}
	public void transferMoney()
	
	{
		System.out.println("hsbc---transfermney");
	}
//separate method of hsbcbank class
public void educationLoan()
	
	{
		System.out.println("hsbc---educationLoan");
	}
public void carLoan()

{
	System.out.println("hsbc---carLoan");
}

//brazil bank method  overriding from brazil bank
public void mutualFund()
{
	System.out.println("hsbc---mutualFund");
}
}
