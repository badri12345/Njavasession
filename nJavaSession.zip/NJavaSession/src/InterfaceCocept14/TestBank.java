package InterfaceCocept14;

public class TestBank {

	public static void main(String[] args) {
	HSBCBank hs = new HSBCBank();
	hs.credit();
	hs.debit();
	hs.transferMoney();
	hs.educationLoan();
	hs.carLoan();
		//dynamic polymorphism, 
	//child class object can be refered by parent interface reference var
	USBank b = new HSBCBank();//child class object can be refer parent interface varible
	b.credit();
	b.debit();
	b.transferMoney();
	//b.educationLoan();-- not possible bcz it is defind the HSBCBank method
	System.out.println(USBank.min_bal);
		
		
	}

}
