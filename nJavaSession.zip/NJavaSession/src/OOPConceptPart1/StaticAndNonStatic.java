package OOPConceptPart1;

public class StaticAndNonStatic {
//global vars - the scope of global vars will be available across all the functions with some condition
String name = "Tom";//non static global variable
static int age = 25;//static global var
public static void main(String[] args) {
	//how to call static method and var ?
	//1.direct calling;or calling by class name
	sum();
	//2. calling by classname;
	StaticAndNonStatic.sum();
	
	System.out.println(age);
	System.out.println(StaticAndNonStatic.age);
	//how to call non static  method and var
	StaticAndNonStatic obj = new StaticAndNonStatic();
	obj.sendMail();
	System.out.println(obj.name);
	// can i access static method by using object reference? the anser is  yes,
	obj.sum();//warning will be given
		
	}
public void sendMail()//non static method
{
System.out.println("send mail method");
}
	public static void sum()//static method
	{
	System.out.println("sum  method");
	{
}
}


}
