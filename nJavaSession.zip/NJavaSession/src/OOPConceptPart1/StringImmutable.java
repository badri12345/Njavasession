package OOPConceptPart1;

public class StringImmutable {

	
	public static void main(String[] args) {
		String s1 = "Java";//in java memory java is created and assign to s1 and s2
		String s2 = "Java";
		s2 = "Naveen";
		System.out.println(s1);
		System.out.println(s2);

	}

}
/*2- string pool in method area
String s1 = "java";
String S2 = "Java";
2- security
3-class load mechanism
4-optimization & performance*/