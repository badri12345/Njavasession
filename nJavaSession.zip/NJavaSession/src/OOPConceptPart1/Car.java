package OOPConceptPart1;

public class Car {
//global varible
	int mod;
	int wheel;
	
	public static void main(String[] args) {
	Car a = new Car();//this line create a object in java memory-new Car(), a is object	reference in java memory
	Car b = new Car(); // a b c is the reference variable of this object
	Car c = new Car();
// new Keyword is used to create the object
	//a b c -> object reference variable
	
	//Before assignig reference
	a.mod = 2015;
	a.wheel = 4;
	
	b.mod = 2014;
	b.wheel = 4;
	
	c.mod = 2013;
	c.wheel = 4;
	System.out.println(a.mod);
	System.out.println(a.wheel);
	
	System.out.println(b.mod);
	System.out.println(b.wheel);
	
	System.out.println(c.mod);
	System.out.println(c.wheel);
	
	
	//After assigning Reference
	a=b;
	b=c;
	c=a;
	a.mod = 10;
	System.out.println(a.mod);//10
	c.mod =20;
	System.out.println(a.mod);
	System.out.println(c.mod);
	
	}

}
