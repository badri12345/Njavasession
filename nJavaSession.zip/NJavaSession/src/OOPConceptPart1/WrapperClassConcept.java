package OOPConceptPart1;

public class WrapperClassConcept {
	
	public static void main(String[] args) {
		String x = "100";
		System.out.println(x+20);
		
		//data conversion: String to int;
		int i = Integer.parseInt(x);
		System.out.println(i+20);
		//Integer , Double,Character,Boolean
		
		//String to double conversion
		String Y = "12.33";
		double d = Double.parseDouble(Y);
		System.out.println(d+10);
		
		//String to charactor== in wraper class no available
		
		
		//String to Boolean;
		
		String k = "true";
		boolean b = Boolean.parseBoolean(k);
		System.out.println(b);
		
		//int to String conversion;
		int j = 200;
		String.valueOf(j+20);
		System.out.println(j);
		String s = String.valueOf(j); //"200"
		System.out.println(s+20);
		
		//Number format exception
		/*String u = "100A";
		Integer.parseInt(u);//NumberFormat	Exception  -- For input string : "100"
*/		
		
		
	}

}
