package OOPConceptPart1;

public class MethodOverLoading {

	
	public static void main(String[] args) {
		MethodOverLoading obj = new MethodOverLoading();
		obj.sum();
		obj.sum(10);
		obj.sum(10,5);
		}
	//method over loading ---> when the method name is same with different argument and different data types or input parameters within the same class
	//you can not create method inside a method
	//duplicate method- --i.e same method name with same number of argument are not allow
	// can we over load main method? - Yes but different parameter
public void sum()// 0 input parameter
{
System.out.println("SUM method---zero param");
}

public void sum(int i)// 1 input parameter
{
	System.out.println("Sum method -- 1 input param");
	System.out.println(i);
}
public void sum(int k, int j)//2 input parameter
{
	System.out.println("Sum method -- 2 input param");
	System.out.println(k+j);
}
}
	

