package AbstractInterface28;

public class ICICIBank implements USBank,RBI {
//RBI Interface override
	public void educationloan(){
		System.out.println("icici---edu loan");
	}
	public void homeloan(){
		System.out.println("icici---home loan");
	}
	public void carloan(){
		System.out.println("icici---car loan");
	}
	//USBank Interface
	public void debit(){
		System.out.println("icici--debit");
	}
	
	public void credit(){
		System.out.println("icici--credit");
	}
	
	
	public void transfermoney(){
		System.out.println("icici--credit");
	}
	
}
