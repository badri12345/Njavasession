package AbstractInterface28;

public class Testbank {

	
	public static void main(String[] args) {
		ICICIBank ic = new ICICIBank();
		ic.educationloan();
		ic.homeloan();
		ic.carloan();
		ic.credit();
		ic.debit();
		ic.transfermoney();
		System.out.println(USBank.min_bal);

	}

}
