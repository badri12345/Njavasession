package AbstractInterface28;

public interface RBI {
public void educationloan();
public void homeloan();
public void carloan();	
	//in interface no method body only method declaration
//we cannot create  object of interface, we can not object instasiate
//no static method
//but variables are static in nature in by default

}


