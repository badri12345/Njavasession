package AbstractInterface28;

public interface USBank
{
	int min_bal = 100;
public void debit();
public void credit();
public void transfermoney();
}