package AstractPackage28;

public class Animal {
public void eat()
{
System.out.println("Animal eat");	
}
}
	
	

