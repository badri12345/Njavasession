package AstractPackage28;

public class Dog extends Animal {

	public static void main(String[] args) {
		Dog d = new Dog();
d.eat();
	}

}
