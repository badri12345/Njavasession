package AstractPackage28;

public class Test extends Shape{

	Test()//constructor
	{
	System.out.println("Test class constructor");	
		
	}

	public static void main(String[] args) {
	
/*Shape s = new Test();//we can create ref obj using child class Test
	s.drawing();
	s.fill();
*/
		Test test = new Test();
	}
void drawing()
{
	System.out.println("Test---drawing");
}
}
