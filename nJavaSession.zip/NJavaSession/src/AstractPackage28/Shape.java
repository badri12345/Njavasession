package AstractPackage28;

public abstract class Shape {
	Shape()
	{
		System.out.println("shape class constructor");
	}

	

	int color;
	abstract void drawing();
	public void fill()
	{
		System.out.println("shape fill");
	}
	//we can not create object of interfce

}
		

