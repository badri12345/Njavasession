/*it is spical class whicha have one object or single instasiate,at atime create single object
if we create another object that point to that single object\
 in oop a singleton class that can have only one object or (instance of the calss) at a time
how to design singleton class in java - 
step1- make sure constructor as private
step2- write a static method that has return type of object of this singleton class(Lazy inialization)*/
package INTERVIEWCOREJAVANAVEEN;

public class SingleTonConcept {
	private static SingleTonConcept SingleToninstance = null;
	public String str;
	private SingleTonConcept(){
	str = "hey i am using singleton pattern";
	}
	//lazy inislization
//getInstanc() return type is class of SingleTonConcept
	public static SingleTonConcept getInstance(){
	if(SingleToninstance == null)
		SingleToninstance = new SingleTonConcept();
		return SingleToninstance;
	}
	
	public static void main(String[] args) {
	
		SingleTonConcept x =SingleTonConcept.getInstance();
		SingleTonConcept y =SingleTonConcept.getInstance();
		SingleTonConcept z =SingleTonConcept.getInstance();
		
		x.str = (x.str).toUpperCase();
		System.out.println(x.str);
		System.out.println(y.str);
		System.out.println(z.str);

z.str = (z.str).toLowerCase();
System.out.println(x.str);
System.out.println(y.str);
System.out.println(z.str);
}}

