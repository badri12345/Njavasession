package INTERVIEWCOREJAVANAVEEN;

/*what is armstrong number
 153
 1*1*1 = 1
 5*5*5 =125
 3*3*3 = 27
 1+125+27 = 153
  407 armstrong number
  0-armstrong number
  1-armstrong number
  370-armstrong number
 
 */


public class ArmstrongNumber {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
