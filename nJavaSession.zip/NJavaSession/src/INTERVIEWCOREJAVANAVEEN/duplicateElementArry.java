package INTERVIEWCOREJAVANAVEEN;

import java.util.HashSet;
import java.util.Set;

public class duplicateElementArry {


	private static Object names;

	public static void main(String[] args) {
	// First solution
		/* String name[] ={"Java","Javascript","Ruby","c","Python","Java","c"};
		//compare each element:o(N*N)---worst solution
		for(int i=0;i<name.length;i++){
			for(int j = i+1;j<name.length;j++){
				if(name[i].equals(name[j])){
					System.out.println("Duplicate element is::;" +name[i]);
				}
				}}*/
	
	
	//using hashSet: java collection it store unique values :o(n)
		System.out.println("other solution *******");
		String names[] ={"Java","Javascript","Ruby","c","Python","Java","c"};
		//set is a interface hash set is a class,hash set implimenting set interface child class
		//--objcet can refer parent interface object variable
		Set<String> store = new HashSet<String>();
		//here "name" is a simple varible string we decalare and "names" is array, name point to java
		for(String name:names){ 
			if(store.add(name)==false){
				System.out.println("Duplicate element is::::" +name);
			}
		}
	//Hash map i am not write here bcz bujhi helani
	}}
