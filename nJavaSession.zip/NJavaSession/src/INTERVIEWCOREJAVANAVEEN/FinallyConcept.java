package INTERVIEWCOREJAVANAVEEN;

public class FinallyConcept {
	
	public static void main(String[] args) {
	//test1();
	//	test2();
		division();
	}
		public static void test1(){
			try{
				System.out.println("inside test1 method");
				throw new RuntimeException("test");
			}catch(Exception e){
				System.out.println("inside catch block");
			}
			
			finally
			{
			System.out.println("inside finally block");	
			}
	}

		public static void test2(){
			try{
				System.out.println("inside  2");
		}
			finally {
				System.out.println("Finally test 2 method");
			}
		}
		
		public static void division(){
			int i = 10;
			try{
				System.out.println("inside try block");
			int k = i/0;
			}
		//catch(ArithmeticException e){
			catch(NullPointerException e){//here also finally block run always
		System.out.println("inside cach block");
		System.out.println("Devide by zero error");
		}
			finally{
				System.out.println("execute this code any execption");
			}
		}}

/*finally -it is a block
final--it is a key word
finalize - it is a method*/