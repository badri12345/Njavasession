package INTERVIEWCOREJAVANAVEEN;
//how to remove strng or special charactor remove
public class RemoveJunk {

	
	public static void main(String[] args) {
	
String   s = "the boy$%45 is bad boy" ;
//Regular Expression :[!a-zA-Z0-9]
	s = s.replaceAll("[~a-zA-Z0-9]", "");
	System.out.println(s);	
		
	
		
		
		
	
	
	}

}

