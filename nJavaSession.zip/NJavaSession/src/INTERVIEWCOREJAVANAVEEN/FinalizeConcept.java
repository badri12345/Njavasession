package INTERVIEWCOREJAVANAVEEN;

public class FinalizeConcept {
	
	public void finalize(){//no need to vreate object it will call automatically
		System.out.println("finalize method");
	}
	public static void main(String[] args) {
	
		FinalizeConcept f1 = new FinalizeConcept();
		FinalizeConcept f2 = new FinalizeConcept();
		f1 =null;//here we create 2 blank object inside the memory
		f2 = null;
	/*if object dont have refernce garvage collect destory that object
		auromatically come to destroy that to free some memory*/
	System.gc();//it is use just to clean up process
	}}


/*finally -it is a block
final--it is a key word
finalize - it is a method*/