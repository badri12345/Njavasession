package INTERVIEWCOREJAVANAVEEN;

/* Reverse a string
 differ btw string and stringBuffer
 do we have reverse function in string*/

public class ReverseString {
	
	public static void main(String[] args) {
	// using for loop method *****************************************
/*		String s = "selenium";
		//String is immutable s.reverse function is not available
		int len = s.length();
		String rev ="";
				for(int i=len-1;i>=0;i--){
		rev = rev+ s.charAt(i);//mu charAt(i) give me that passing the specific index
		
				}
	
				System.out.println(rev);
		
	}}
*/
		
		//using string buffer class*****************************************
		/*String is immutable, string buffer is muatable- 
		string buffer having REVERSE FUNCtion is there*/

		String s = "Selenium";
StringBuffer sf = new StringBuffer(s);
System.out.println(sf.reverse());
}}

		
		
		
		
		
		//****************************************************************
		
	/*	String s = "**********";
		//String is immutable s.reverse function is not available
		int len = s.length();
		String rev ="";
				for(int i=len-1;i>=0;i--){
		rev = rev+ s.charAt(i);//mu charAt(i) give me that passing the specific index
		System.out.println(rev);
				}
	
				
		
	}}
*/