package INTERVIEWCOREJAVANAVEEN;

/*it is number which divided by itself or zero*/

public class PrimeNumber {

	public static boolean isprimeNumber(int num) {
		/*
		 * edge/ corner cases ;;; 2 is the lowest prime numbet 3 is also
		 * primenumbet 0 an 1 is not prime number
		 */

		if (num <= 1) {
			return false;
		}

		for (int i = 2; i < num; i++) {
			if (num % i == 0) {
				return false;
			}
		}
		return true;
	}

	public static void getPrimeNumber(int num){
		System.out.println("prime number upto " + num);
		System.out.println();
		
		for(int i=2;i<=num;i++){
			if(isprimeNumber(i))
				System.out.println(i  +" ");
		}
	}
		
	
	
	public static void main(String[] args) {
    System.out.println ("2 is prime number:  "  +isprimeNumber(2));
    System.out.println ("3 is prime number:  " +isprimeNumber(3));
    System.out.println ("4 is prime number:  " +isprimeNumber(4));
    System.out.println ("17 is prime number:  " +isprimeNumber(17));
    System.out.println ("10 is prime number:  " +isprimeNumber(10));

    getPrimeNumber(20);
    getPrimeNumber(7);
	}

}
