package INTERVIEWCOREJAVANAVEEN;

public class SwapwithoutThirdvariable {


	public static void main(String[] args) {

int x=5;
int y=10;

//with using third var : t
/*    int t;

t=x; //5
x=y; //10
y=t; //5

System.out.println(x);
System.out.println(y);   */
	
//without using 3rd varible using + operator

/*x= x+y; //15
y= x-y; //5
x= x-y;//10

System.out.println(x);
System.out.println(y);*/
	
//without using 3rd varible  * operator

x= x*y; //50
y= x/y; //5
x= x/y;//10

System.out.println(x);
System.out.println(y);	




	}

}
