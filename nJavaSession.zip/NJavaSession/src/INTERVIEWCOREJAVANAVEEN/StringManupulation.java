package INTERVIEWCOREJAVANAVEEN;

public class StringManupulation {

	public static void main(String[] args) {
		String str = "the rains have started here";
		String str1 = "the Rains have started here";
		System.out.println(str.length()); //lenghth checking
		System.out.println(str.charAt(5));//check the 5th location
		System.out.println(str.indexOf('s'));//first occurancek index of S position
		System.out.println(str.indexOf('s',9));//check the second postn which start to 9th postn hard coded anothe way
		System.out.println(str.indexOf('s',str.indexOf('s')+1));//2nd occurance value
		System.out.println(str.indexOf("have"));
		System.out.println(str.indexOf("hallo"));//it will return -1
		//String comparision
		System.out.println(str.equals(str1));
		//string jadi same habani then out put will come FALSE
		//small letter and capital letter ignore kariki compare kale
		System.out.println(str.equalsIgnoreCase(str1));
		//substring-mane gote line ra particular word darkar
		System.out.println(str.substring(0,9));
		//trim use before space and after space
		String s= "  Hello Workd  ";
		System.out.println(s.trim());
		//if i want to remove beteen space Hello Workd then below code
		System.out.println(s.replace(" ", ""));
		//i want date change to 01-01-2017 to 01/01/2017
		String date = "01-01-2017";
		System.out.println(date.replace("-", "/"));
		//split
	
		String test = "hallow_world_Test_Selenium";
		String testval[]=test.split("_");
		for(int i=0;i<testval.length;i++){
		System.out.println(testval[i]);
		}
		//string concatinatiob
		String s2 = "cares";
		System.out.println(s2.concat("s"));
		
		// add string
		String x = "hello";
		String y = "world";
		int a = 100;
		int b= 200;
		System.out.println(x+y);
		System.out.println(a+b);
		System.out.println(x+y+a+b); //output helloworld100200
		//carefull see execution always left to right
		System.out.println(a+b+x+y);//output 300helloworld
		System.out.println(x+y+(a+b));// output helloworld300
		
		
		
		
		
		
	}}