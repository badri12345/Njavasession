package INTERVIEWCOREJAVANAVEEN;

public class ReverseIntiger {

	public static void main(String[] args) {
		//1st using alogorithim
	int num = 123456;
	int rev = 0;
	
	while(num!=0){
		rev= rev*10 + num % 10;
		num = num/10;
	}
	System.out.println("Reverse num is :: " +rev);
	
	//String buffer Reverse Method
	long num1 = 1234567;
	System.out.println(new StringBuffer(String.valueOf(num1)).reverse());
	
	}
}
