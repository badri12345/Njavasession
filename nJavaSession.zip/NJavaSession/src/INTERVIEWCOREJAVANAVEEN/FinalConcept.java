package INTERVIEWCOREJAVANAVEEN;

public class FinalConcept {
public static void main(String[] args) {
	final int i =10;//cinstanst value we cant modify;it privent inherinace

	

	}

}
