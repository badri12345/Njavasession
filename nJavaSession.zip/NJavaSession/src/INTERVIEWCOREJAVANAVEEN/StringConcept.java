package INTERVIEWCOREJAVANAVEEN;

public class StringConcept {

	public static void main(String[] args) {
	
		String s1 ="Java";
		String s2 = "Java";

		System.out.println(s1);
		System.out.println(s2);
	}

}
