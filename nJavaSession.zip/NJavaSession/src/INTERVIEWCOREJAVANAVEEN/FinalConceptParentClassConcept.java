package INTERVIEWCOREJAVANAVEEN;

public  final class FinalConceptParentClassConcept {
//to prevent inheritance  to prevent over riding
	public void start(){
		System.out.println("PARENT Start parent method");
	}
}
/*finally -it is a block
final--it is a key word
finalize - it is a method*/