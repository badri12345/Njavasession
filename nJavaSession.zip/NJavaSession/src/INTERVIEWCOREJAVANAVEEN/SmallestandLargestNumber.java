package INTERVIEWCOREJAVANAVEEN;

import java.util.Arrays;

public class SmallestandLargestNumber {


	public static void main(String[] args) {

int number[] = {-100,24,50,-88,987656,987657};
int largest = number[0];
int smallest = number[0];
//time complxity os o(n)
for(int i=1;i<number.length;i++){//why int i=1 bcz largest and smallest alredy store zero position
if(number[i]>largest){//value is  24
largest = number[i];
}
else if(number[i]<smallest){
smallest = number[i]; //88
}
}
System.out.println("\n given array is::::" +Arrays.toString(number));
System.out.println("Largest element is::::" +largest);
System.out.println("Duplicate element is::::" +smallest);
		
		
		
		

	}

}
