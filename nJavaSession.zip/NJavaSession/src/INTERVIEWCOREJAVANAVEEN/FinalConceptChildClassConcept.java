package INTERVIEWCOREJAVANAVEEN;

public class FinalConceptChildClassConcept extends FinalConceptParentClassConcept {

	public void start(){// method over riding
		System.out.println("CHILD class Start method");
	}
}
