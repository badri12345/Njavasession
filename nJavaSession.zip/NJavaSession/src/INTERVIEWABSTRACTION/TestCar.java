package INTERVIEWABSTRACTION;

public class TestCar {

		public static void main(String[] args) {
	
			Bmw b = new Bmw();
			
			b.start();
			b.stop();
			b.refual();
			b.theftSafety();
			
			Car c = new Bmw();
			c.start();
			c.stop();
			c.refual();
			//c.theftSafety(); not possible
			

	}

}
