package INTERVIEWABSTRACTION;

public class HDFCBank extends Bank{

	public void loan(){
	System.out.println("HDFC Loan Method");	
	}
	public void loan1(){
		System.out.println("HDFC1 Loan Method");
}}
