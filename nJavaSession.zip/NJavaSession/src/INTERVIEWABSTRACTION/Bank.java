package INTERVIEWABSTRACTION;

/*-abstract class must contain public abstract class Bank
-in abstract class should be abstract in nature  mne only method declaration no bode
to hide some implimentaion logic
implimentation logic defind in child class 
partial abstraction
Hiding the implimentation logic
abstract class can have abstarct method and non abstract method
when ever we define partial implementaion in that time we use abstract class
 */

public abstract class Bank {
	
	
	int amt = 100;
	final int rate = 10;
	static int loanRate = 5;
	
	public abstract void loan();//abstract metod - no method body
	
public void credit(){
	System.out.println("Bank-----Credit");
}
	
public void debit(){
	System.out.println("Bank-----Debit");
}
	
}
