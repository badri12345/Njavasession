package INTERVIEWABSTRACTION;

public class TestBank {

	public static void main(String[] args) {
	
		HDFCBank hb = new HDFCBank();
		hb.credit();
		hb.debit();
		hb.loan();
		hb.loan1();
	
	//	Dynamic polimorphism
	
		
		Bank b = new HDFCBank();
		b.credit();
		b.debit();
		b.loan();
	//	b.loan1;  - we cant get here loan1 method here
	}

}
