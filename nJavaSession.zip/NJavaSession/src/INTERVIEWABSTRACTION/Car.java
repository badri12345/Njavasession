package INTERVIEWABSTRACTION;

public interface Car {
	
	int amt = 100;//by default is final
	final int wheel = 10;
	static int loanRate = 5;
/*Always define only abstract method
no method body
only method declaration
we achieve 100% abstraction
can not create the object of interface
only final and static variable*/
	
	public void start();
	public void stop();
	public void refual();
	
}