package INTERVIEWABSTRACTION;

public class Bmw implements Car{


	public void start(){
	System.out.println("BMW---start");
}
	
	
	public void stop(){
		System.out.println("BMW---stop");
	}
	
	public void refual(){
		System.out.println("BMW---Refual");
	}
	
		public void theftSafety(){
			System.out.println("BMW---Refual");	
	}}
	
	
