package OOPConceptPart2;

public class OverRidingBelowclsses {

}
