package OOPConceptPart2;

public class BMW extends Car //-"has a relation ship"car is parent class and BMW  is child class
{
	//when method is present in parent class as well as in child class with the same name and same number of argument, is called Method-Over riding
	//method overloading
	public void start() { //over riden Method
		System.out.println("BMW---Start");
	}

	public void theftSafety() {
		System.out.println("BMW---theftSafety");

	}
}
