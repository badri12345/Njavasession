package OOPConceptPart2;

public class Car extends Vechile {

	public void start()
	{
		System.out.println("car ---start");		
	}
	public void stop()
	{
		System.out.println("car ---stop");		
	}
	public void refuel()
	{
		System.out.println("car ---refual");		
	}
}
