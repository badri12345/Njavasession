package OOPConceptPart2;

public class Vechile {
	public void engine()
	{
		System.out.println("Vechile-- Engine");
	}
	

}
