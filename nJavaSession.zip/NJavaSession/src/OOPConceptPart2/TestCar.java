package OOPConceptPart2;

public class TestCar {

	public static void main(String[] args) {
	BMW b = new BMW();//parent class method will call 
	//Static polymorphism -- compile time polymorphism
	// polymorphism - means - one to many  many method it means method over riding, same name, same method argument
	b.start();
	b.stop();	
	b.refuel();
	b.theftSafety();
    b.engine();
	
	
Car c = new Car();
c.start();
c.stop();
c.refuel();
// c.theftSafety()- car class object C can not acess BMW class of theftSafety (), bcz parent cant inhert child class method
// Top casting- means dynamic polimorphism
Car c1 = new BMW();//child class object can be referred by parent class reference variable- dynamic polymorphism--run time polymorphism
c.start();
c.stop();
c.refuel();
// c.theftSafety()- car class object C can not acess BMW class of theftSafety (), bcz parent cant inhert child class method, it is security issue,u can use ferenece but not praporties
	//Down cast
//BMW b1 = new Car();- error asiba not possible- parent can not fit with child
// we can cast
// Down Casting
BMW b1 = (BMW)new Car();
// we are getting ClasscastException in run time bcz parent can not fit child class



	}

}
