package Constructor;

public class ConstructorCar27 {
String name;
int price;
String engine;
public ConstructorCar27(String name,int price, String engine)
{
this.name = name;
this.price = price;
this.engine = engine;

}


public static void main(String[] args) {
ConstructorCar27 obj1= new ConstructorCar27("BMW", 10, "Automatic");
ConstructorCar27 obj2 = new ConstructorCar27("Audi", 20, "Automatic");
ConstructorCar27 obj3= new ConstructorCar27("Honda", 5, "Manual");

System.out.println(obj1.name + " " +obj1.price+ " " +obj1.engine);

	}

}
