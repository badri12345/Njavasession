package Constructor;

public class SuperB1 extends SuperA1 {
public void B1()
{
//super(10);- out put will come parent method public void A1(int i) with 10
	//super key wordis the first stament in one constructor
	//super key word must be 1 only we can not write 2 times super key word in single constuctor
	System.out.println("Child class const");
	
}


	public static void main(String[] args) {
		
		SuperB1 obj = new SuperB1();
		obj.B1();
		
		
	}

}
