package Constructor;

public class SuperA1 {
public void A1()
{
System.out.println("paret class cont");	
}

public void A1(int i)
{
System.out.println("paret class cont with value of i " +i);	
}
	
	public static void main(String[] args) {
		

	}

}
