package Constructor;
//it does not return any values, we cannot write eturn statement in constructor
//class name and constructor name is same
//over load constructor

//�	this() : can be used to invoke a constructor of the same class.
public class ConstructorConcept27 {
//class variable instance variable 
	String name;
	int age;
	
	public ConstructorConcept27()// 0 paramiter
	{
		System.out.println("Default cont");
	}
	public ConstructorConcept27(int i)// 1 paramiter
	{
		System.out.println("one paramiter ");
		System.out.println(i);
	}
	
	public ConstructorConcept27(int i, int j)// 2 paramiter
	{
		System.out.println("Two paramiter ");
		System.out.println(i + " " +j);
	}
	
	
	public ConstructorConcept27(String name, int age)
	{
		
		//�	this() : can be used to invoke a constructor of the same class.
		/*this.name = name; //this.classvar = localvar
		this.age = age;
		System.out.println(name +" " +age);*/
		
		name = name;
		age = age;
		System.out.println(name +" " +age);
	}
	
	
	public static void main(String[] args) {
		ConstructorConcept27 obj27 = new ConstructorConcept27();//only default constructor will print
		ConstructorConcept27 obj271 = new ConstructorConcept27(10);
		ConstructorConcept27 obj272 = new ConstructorConcept27(10,20);
		ConstructorConcept27 obj273 = new ConstructorConcept27("tom",20);
	}

}
