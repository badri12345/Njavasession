package Constructor;

public class ConstructorWithThisKeyWord {
	//class variable
	String name;
	int age;
	

	public ConstructorWithThisKeyWord(String name, int age){
	//when ever initalise the global variable or class variable with the current value of constructor in that case we use This key word
	this.name = name;//this can be used to invoke a constructor of the same class.
	this.age = age;
	{
		System.out.println(name);
		System.out.println(age);
	}
	}
	
	public static void main(String[] args) {
		ConstructorWithThisKeyWord obj = new ConstructorWithThisKeyWord("Tom",30);
	}

}
