package nJavaPackage;

public class WrapperClassParseInt {

	public static void main(String[] args) {
	String x = "100";
	System.out.println(x+20);
	//data conversion string to intiger
	int i = Integer.parseInt(x);
	System.out.println(x+20);
	//Intiger to double conversion;
	String y ="12.33";
	double d = Double.parseDouble(y);
	System.out.println(d+10);
	//String to char no parsing method
	//String K = "A";//forgot string to char
	//String to Boolean
	String S = "true";
	boolean b = Boolean.parseBoolean(S);
	System.out.println(b);
	//int to string conversion
	int j = 200;
	System.out.println(j+20);
	
	String S1 = String.valueOf(j);
	System.out.println(S1+20);
	
	String u = "100A"; //it is not pure string value so we are getting number format exception
	Integer.parseInt(u);//showing number format intiger bcz the string is not pure string vlue so we are getting value
	
	}

}
