package nJavaPackage;

public class LoopConcept {

	
	public static void main(String[] args) {
		//while loop - if we will not give incrimental operator the program will go incrimental operators
		//disadvantage - it will generate infanite loop if you dont give incrimental/decremental part
		/*int i = 1; //iniatilizaion
		while (i<=10)//conditional part
		{
			System.out.println(i);
			i= i+1;//incrimenat part
		}
		}*/
	
	
	//for loop
	
/*for (int j=1;j<=10;j++)//iniatilization, conditional , incriment
{
	System.out.println(j);
}*/

	
	
	//for print 10 to  1
/*for (int k=10;k>=0;k--)//iniatilization, conditional , incriment
{
	System.out.println(k);
}*/

		for (int k=10;k>=-10;k--)//iniatilization, conditional , incriment
		{
			System.out.println(k);
		}

	}
}


