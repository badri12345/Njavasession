package nJavaPackage;

public class ExceptionHandling29 {
//int a= 10;
		public static void main(String[] args) {
		//uncaught exception
		//	int i =9/0;
		//	System.out.println(i);// we can see arithmatic excetion, we need to catch it
			
//cought exception
//Thread.sleep(2000);	
	//below null pointer exception
			
		/*	ExceptionHandling29 obj = new ExceptionHandling29();	
		obj = null;
		System.out.println(obj.a);
		}
*/
//try-catch block:
			try
			{
				int i = 9/0;//this code through the exception
			}
			
			catch(ArithmeticException e)
			//catch(Throwable e)// throwable-it is a super class of java language
			{
			e.printStackTrace(); //it print abc , not terminating program, it give which line error is commig
			System.out.println(e.getMessage());
			}	
			System.out.println("ABC");
			System.out.println("ABC");
			System.out.println("ABC");
			}}