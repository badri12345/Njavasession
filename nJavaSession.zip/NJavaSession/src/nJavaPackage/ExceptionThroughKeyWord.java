package nJavaPackage;
//through-it is used when u have to throgh exception in delibertly
public class ExceptionThroughKeyWord {

	
	public static void main(String[] args) {
	System.out.println("ABC");
	try
	{
throw new Exception("naveen Exception");
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	System.out.println("PQR");
	}

}
