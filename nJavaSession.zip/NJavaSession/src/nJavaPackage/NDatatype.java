package nJavaPackage;

public class NDatatype {

	public static void main(String[] args) {
		//int
		int i= 10;//int is a data type i is variable  10 is vale, duplicate varible not allow 
		// we can declare int  i = 10  and i = 20, its valid, current vale is i = 20
		double d = 12.78;//we can store double d = 12; its valid bcz it store 12.00 in memory
		char c = 'a'; //it should be single digit value only ..not two charactor
		boolean b1 = true;
		//String  is not a datatype, it is a class, but yes we can use data type for a string value
		String s = "hello world";
		
		
		

	}

}
