package nJavaPackage;
//finalize - it is a method just before object call galabge collector it is automatically finalize method
//call before just to do clean off the process
public class FinalConcept {

	
	public static void main(String[] args) {
	//restrict the value, we cant changethe value.it is constant value
		
		final int i = 10;

	}

}
