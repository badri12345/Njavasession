package nJavaPackage;
//
public class ExceptinThrowskeys {
//within the method we are using throws key word
	public static void main(String[] args)throws ArithmeticException
	{ 
		ExceptinThrowskeys obj = new ExceptinThrowskeys();
		obj.sum();
		System.out.println("ABC");
	}
public void sum()throws ArithmeticException
{
	try{
		div();
	}
	catch(ArithmeticException e)
	{
	}
	}

	

public void div() throws ArithmeticException
{
	int i = 9/0;
}
}

