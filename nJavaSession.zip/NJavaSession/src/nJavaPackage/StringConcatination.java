package nJavaPackage;

public class StringConcatination {

	
	public static void main(String[] args) {
	int a = 100;
	int b = 200;
	String x = "hello";
	String y ="world";
	System.out.println(a+b+x+y);
	System.out.println(a+b+(x+y));
	System.out.println(a+b+x+y+a+x+b+y);
	System.out.println(a+b+x+y+a+b);
	System.out.println("The value of a is :" +a);
	System.out.println("The value of a is :" +b);
	System.out.println("The value of a and b is :" +(a+b));
	//println statement given new line, Print statement is giving same line
	
	System.out.print("Hellow Selenium");
	System.out.println("Hello Testing");
	//Different comparision in java
	
	
	
	
	
	}

}
