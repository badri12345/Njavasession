package Collection_ListConcept;

import java.util.Iterator;
import java.util.LinkedList;

public class practicearray {


	public static void main(String[] args) {
	
LinkedList<String> ll = new LinkedList<String>();
//add
ll.add("test");
ll.add("qtp");
ll.set(2,"TOM");
System.out.println(ll.get(2));
System.out.println("content of linkedlist:" +ll);



System.out.println("Advance for loop");
for(String str: ll){
System.out.println(str);
}
//iteator
System.out.println("####Using Iterrator####");
Iterator<String> it = ll.iterator();
while(it.hasNext()){
	System.out.println(it.next());
}

//while loop 
System.out.println("####Using while loop####");
int num=0;
while(ll.size()>num){
	System.out.println(ll.get(num));
	num++;
}

}
	}


