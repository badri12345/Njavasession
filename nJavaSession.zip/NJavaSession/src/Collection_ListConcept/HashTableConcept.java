package Collection_ListConcept;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Set;

public class HashTableConcept {


	public static void main(String[] args) {
		Hashtable  h1 = new Hashtable();
		
		h1.put(1, "TOM");
		h1.put(2, "Test");
		h1.put(3, "Java");
	
		/*create a clone copy/shallow copy
		we have created two object h1 and h2 we just create clone h1.clone() and typecast it hashtable and store into h2 */
		
		Hashtable  h2 = new Hashtable();
		h2 = (Hashtable)h1.clone();
		System.out.println("the values from h1"  +h1);
		System.out.println("the values from h2"  +h2);
		
		h1.clear();
		System.out.println("the values from h1"  +h1);
		System.out.println("the values from h2"  +h2);
		
		//contains value if exist then print
		Hashtable st = new Hashtable();
		st.put("A", "Naveen");
		st.put("B", "Manager");
		st.put("C", "Selenium");
		
		if(st.containsValue("Naveen"))
		System.out.println("value is found");
		
		/*print all the values from hashtable using -- Enumeration Elements()
		return an enumeration of the value in this hash table.use the 
		enumuration method on the return object to fetch the element sequentially	*/	
		System.out.println("#########ENUMERATION VALY PRINT ##########");
		Enumeration e = st.elements();
		//System.out.println("print value from st");
		while (e.hasMoreElements()){
			System.out.println(e.nextElement());
		}
		/*get all the value from hashtable using --entrySet() - set of hashtable value
		Remember - it is store value not ordering we use array list it doesnot provide value
		0 1 2 3 we use for loop here we use enumertaion or entry set*/
		
		System.out.println("#########Entry set PRINT ##########");
		Set s = st.entrySet();
		System.out.println(s);
	/*	equal method there  we create another hash table with exact value we check both the 
		hash table same or not*/
		
		System.out.println("#########Both are equal ##########");
		
		Hashtable st1 = new Hashtable();
		st1.put("A", "Naveen");
		st1.put("B", "Manager");
		st1.put("C", "Selenium");
		st1.put("C", "Selenium"); //it contains only unique values
		//no null key and  null values::: 
		//st1.put("D", null)//null pointer exception
		
		//chk both the hash table equal or not
		
		if(st.equals(st1))
			System.out.println("both are equal");

		// get the value from key:
		System.out.println(st1.get("B"));
		
		//Hash code method - it return the hashcode of hashtable object
		System.out.println("the hash code value of st1:" +st1.hashCode());
		// generic also we can defind
		
	//	Hashtable <String, String> st3 = new Hashtable<String, String>();
		
		
		
		
	}

}
