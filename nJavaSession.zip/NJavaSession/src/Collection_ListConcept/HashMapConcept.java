package Collection_ListConcept;

//Related to employee java
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapConcept {

	
	public static void main(String[] args) {
	/*Hashmap is a class impliment Map Interface extends Abstarctmap
    it contains only unique element, 
    it can store one null key or multiple null keys
    Store the value - key - value pair
    It may have one null key and multiple null values
    it maintain no orders
    hashmap is non synchronized  mane it is used multithreading envirnment, 
    more than one thered acess  and process hash map simutaniousy 
    performace of hash map increased auto matically - not thread safe
    But remeber Hash table is synchronised only one thread can acess
    But Hash map synronisation the biggest problem is FAIL FIRST problem is there
    what is that that mence if in hash map 2 key value pair is there and one thread acess first value 1 - a
    and change the value is 1 = b, in exact time another thread executing and he expect same value that is 1 - a
        but first thread change the object that is called FAIL FIRST problem we can say concurrent 
    modification
    concurrent modification exception - FAIL FAST condition
    */
		
		HashMap<Integer, String> hm = new HashMap<Integer, String>();
		hm.put(1, "Selenium");
		hm.put(2, "qtp");
		hm.put(3, "TestComplete");
		hm.put(4, "RFT");
		
		System.out.println(hm.get(1));
		System.out.println(hm.get(4));
		
		/*if we want to fetch the value in hash map we use entry set and entry concept
		 m is reference hm.entrySet() value store all the value in availble in hash map
		Entry set is an interface which used to travese hash map*/
	    for(Entry m : hm.entrySet()){
		System.out.println(m.getKey()+" " +m.getValue());
	    }
		//remove method
	    System.out.println(hm);
		hm.remove(3);
		System.out.println(hm);
		
		// using employee class object how we fetch that it is related to employee.java
		
		System.out.println("####Using Employee Class####");
		
		HashMap<Integer, Employee> emp = new HashMap<Integer, Employee>();
		//Employee is a class refernce here
		Employee e1 = new Employee("TOM", 25, "Admin");
		Employee e2 = new Employee("Piter", 25, "QA");
		Employee e3 = new Employee("Steve", 25, "DEV");
		
		emp.put(1, e1);
		emp.put(2, e2);
		emp.put(3, e3);
		
		for(Entry<Integer, Employee> m : emp.entrySet()){
			int key = m.getKey();
			Employee e = m.getValue();
			System.out.println("Employee " + key + "info");
			System.out.println(e.name + " " + e.age + " "+e.dept);
					
		
		}
	
		
		
	}
	}


