package Collection_ListConcept;
//connect to Employee.java
import java.util.ArrayList;
import java.util.Iterator;



public class ArrayListConcept {

	/* can contain duplicate value, maintaion insertion order, 
	 it is synchronized, it allows you random acess to fetch element because 
	 it store the values in the basis of indexes, */

	public static <E> void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList ar = new ArrayList();
ar.add(10);
ar.add(20);
ar.add(30);
ar.add(40);
ar.add(50);
ar.add(12.5);
ar.add("Test");
System.out.println(ar.size());

System.out.println(ar.get(2));
// to print all the value from arraylist : for loop
// using itertor

for(int i=0;i<ar.size();i++){
	System.out.println(ar.get(i));
}

//non generic vs generic 
ArrayList<Integer> ar1 = new ArrayList<Integer>();
ar1.add(100);
// sting not allow  showing error ar1.add("seleium");
 
ArrayList<String> ar2 = new ArrayList<String>();
ar2.add("Test");
//If we don�t know what kind of data we need to add that syntax is below
ArrayList<E> ar3 = new ArrayList<E>();
Employee e1 = new Employee("Naveen", 27, "QA");
Employee e2 = new Employee("Tom", 28, "DEV");
Employee e3 = new Employee("Peter", 29, "Admin");

//create array list defind here employee objct
ArrayList<Employee> ar4 = new ArrayList<Employee>();
ar4.add(e1);
ar4.add(e2);
ar4.add(e3);
//iterator to traverse the value

Iterator<Employee> it = ar4.iterator();
//we are use while loop bcz we are using object here, for loop use where we use index, thogh we are using objct here we are use  while loop
while(it.hasNext()){ 
	Employee emp = it.next();
	System.out.println(emp.name);
	System.out.println(emp.age);
	System.out.println(emp.dept);
}


// addAll() #################### Important
System.out.println("#########");
ArrayList<String> ar5 = new ArrayList<String>();
ar5.add("Test");
ar5.add("seleniums");
ar5.add("QTP");


ArrayList<String> ar6 = new ArrayList<String>();
ar6.add("Dev");
ar6.add("Java");
ar6.add("JavaScript");
//here adding second list object (ar6) to first list oblect(ar5) how to do that we can use addall()
ar5.addAll(ar6);

for(int i=0; i<ar5.size();i++){
	System.out.println(ar5.get(i));
}

	//Remove All method also there in array list

//removeAll() #################### Important
System.out.println("####Remove All#####");
ar5.removeAll(ar6);

for(int i=0; i<ar5.size();i++){
	System.out.println(ar5.get(i));
}

	//if we check common part retaion all
System.out.println("#######RETAIN VALUE#########");
ArrayList<String> ar7 = new ArrayList<String>();
ar7.add("Test");
ar7.add("seleniums");
ar7.add("QTP");


ArrayList<String> ar8 = new ArrayList<String>();
ar8.add("Test");
ar8.add("Java");

ar7.retainAll(ar8);
for(int i=0; i<ar7.size();i++){
	System.out.println(ar7.get(i));
}
	
	}

}
